﻿利用するにはJava SE 7以降がインストールされている必要があります。
インストールされていない場合は下記のURLからインストールしてください。

http://www.java.com/ja/

■ファイル内容
MagMousePad_Server.jar
    アプリの本体ファイルです。
MagMousePad_Server.bat
    アプリをコマンドラインから実行するファイルです。
README.txt
    このテキストファイルです。

実行するにはMagMousePad_Server.jarをダブルクリックしてください。
実行されない場合はMagMousePad_Server.batをダブルクリックして実行できるかを試してください。
それでも実行できない場合、Java SE 7 以降がインストールされていない可能性があります。

■使い方
1、PCとAndroid端末が同じWiFiに接続されていることを確認してください。

2、Android端末にインストールしたMagMousePadを起動し、自動接続ボタンを押してください。

3、PCをAndroid端末から操作できたら、接続完了です。


接続できない場合は以下の手動設定の手順を行ってください。


■手動設定
1、PCとAndroid端末が同じWiFiに接続されていることを確認してください。

2、MagMousePad_Server を実行して表示されるIPアドレスを確認してください。

3、Android端末にインストールしたMagMousePadを起動し、確認したIPアドレスを入力後、
   接続ボタンを押してください。

4、PCをAndroid端末から操作できたら、接続完了です。