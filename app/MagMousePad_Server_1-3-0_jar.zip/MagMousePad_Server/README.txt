﻿利用するにはJava SE 7以降がインストールされている必要があります。
インストールされていない場合は下記のURLからインストールしてください。

http://www.java.com/ja/

■ファイル内容
MagMousePad_Server.jar
    アプリの本体ファイルです。
MagMousePad_Server.bat
    (Windows向け)アプリをコマンドラインから実行するファイルです。
MagMousePad_Server.sh
    (Linux向け)アプリをコマンドラインから実行するファイルです。
MagMousePad_Server.command
    (Mac OSX向け)アプリをコマンドラインから実行するファイルです。
README.txt
    このテキストファイルです。

Windowsの場合はMagMousePad_Server.bat
Mac OSXの場合はMagMousePad_Server.command
Linuxの場合はMagMousePad_Server.sh
をそれぞれダブルクリックして実行できます

command、shファイルに実行権限がない場合はターミナルで以下のコマンドで実行権限を付与する必要があります
$ chmod 755 MagMousePad_Server.sh
$ chmod 755 MagMousePad_Server.command

コマンドラインから直接実行する場合は以下のコマンドを実行してください
$ java -jar MagMousePad_Server.jar

実行できない場合、Java SE 7 以降がインストールされていないかパスが通っていない可能性があります

■使い方
1、PCとAndroid端末が同じWiFiに接続されていることを確認してください。

2、PCにダウンロードしたMagMousePad_Server を起動してください。

3、Android端末にインストールしたMagMousePadを起動し、自動接続ボタンを押してください。

4、PCをAndroid端末から操作できたら、接続完了です。


接続できない場合は以下の手動設定の手順を行ってください。


■手動設定
1、PCとAndroid端末が同じWiFiに接続されていることを確認してください。

2、MagMousePad_Server を起動して表示されるIPアドレスを確認してください。

3、Android端末にインストールしたMagMousePadを起動し、確認したIPアドレスを入力後、
   接続ボタンを押してください。

4、PCをAndroid端末から操作できたら、接続完了です。

■アップデート方法
古いバージョンのファイルを上書きすることで更新できます

