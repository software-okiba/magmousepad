#!/bin/bash
cd `dirname $0`
java -jar MagMousePad_Server.jar
