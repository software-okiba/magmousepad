#!/usr/bin/bash

javaw -jar MagMousePad_Server.jar

